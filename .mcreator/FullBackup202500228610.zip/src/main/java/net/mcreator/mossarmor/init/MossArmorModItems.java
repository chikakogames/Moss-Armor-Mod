/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mossarmor.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.Item;

import net.mcreator.mossarmor.item.MossSwordItem;
import net.mcreator.mossarmor.item.MossShovelItem;
import net.mcreator.mossarmor.item.MossPickaxeItem;
import net.mcreator.mossarmor.item.MossPartItem;
import net.mcreator.mossarmor.item.MossHoeItem;
import net.mcreator.mossarmor.item.MossAxeItem;
import net.mcreator.mossarmor.item.MossArmorItem;
import net.mcreator.mossarmor.MossArmorMod;

public class MossArmorModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(MossArmorMod.MODID);
	public static final DeferredItem<Item> MOSS_ARMOR_HELMET = REGISTRY.register("moss_armor_helmet", MossArmorItem.Helmet::new);
	public static final DeferredItem<Item> MOSS_ARMOR_CHESTPLATE = REGISTRY.register("moss_armor_chestplate", MossArmorItem.Chestplate::new);
	public static final DeferredItem<Item> MOSS_ARMOR_LEGGINGS = REGISTRY.register("moss_armor_leggings", MossArmorItem.Leggings::new);
	public static final DeferredItem<Item> MOSS_ARMOR_BOOTS = REGISTRY.register("moss_armor_boots", MossArmorItem.Boots::new);
	public static final DeferredItem<Item> MOSS_PART = REGISTRY.register("moss_part", MossPartItem::new);
	public static final DeferredItem<Item> MOSS_SWORD = REGISTRY.register("moss_sword", MossSwordItem::new);
	public static final DeferredItem<Item> MOSS_AXE = REGISTRY.register("moss_axe", MossAxeItem::new);
	public static final DeferredItem<Item> MOSS_PICKAXE = REGISTRY.register("moss_pickaxe", MossPickaxeItem::new);
	public static final DeferredItem<Item> MOSS_SHOVEL = REGISTRY.register("moss_shovel", MossShovelItem::new);
	public static final DeferredItem<Item> MOSS_HOE = REGISTRY.register("moss_hoe", MossHoeItem::new);
	// Start of user code block custom items
	// End of user code block custom items
}