package net.mcreator.mossarmor.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class MossPartItem extends Item {
	public MossPartItem() {
		super(new Item.Properties().food((new FoodProperties.Builder()).nutrition(5).saturationModifier(0.3f).build()));
	}
}